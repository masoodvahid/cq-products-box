# cq-products-box
Woocommerce same category products show in box as icons

use as a shortcode like this :
```
[cq-show-card slug=CATEGORY-1-SLUG,CATEGORY-2-SLUG]
```
