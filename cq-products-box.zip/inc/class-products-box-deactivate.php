<?php
class Products_box_Deactivator {
    public static function deactivate() {

	}
}