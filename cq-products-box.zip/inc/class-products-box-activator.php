<?php
class Products_box_Activator {
    function activate(){
		
	}
}